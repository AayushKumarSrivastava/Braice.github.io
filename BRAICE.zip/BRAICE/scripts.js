document.addEventListener('DOMContentLoaded', function() {
    const hamburgerMenu = document.querySelector('.hamburger-menu');
    const navMenu = document.querySelector('.nav-menu');

    hamburgerMenu.addEventListener('click', function() {
        // Toggle open class on hamburger menu
        this.classList.toggle('open');

        // Toggle open class on nav menu
        navMenu.classList.toggle('open');
    });
});